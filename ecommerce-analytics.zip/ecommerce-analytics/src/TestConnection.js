require('dotenv').config();

const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI;

console.log('MONGO_URI:', MONGO_URI); // Log URI to check if it's being read

if (!MONGO_URI) {
    console.error('MONGO_URI is not defined in .env file');
    process.exit(1);
}

mongoose.connect(MONGO_URI) // Remove deprecated options
    .then(() => {
        console.log('Connected to MongoDB');
        mongoose.connection.close(); // Close connection after test
    })
    .catch((error) => {
        console.error('Error connecting to MongoDB:', error.message);
    });
