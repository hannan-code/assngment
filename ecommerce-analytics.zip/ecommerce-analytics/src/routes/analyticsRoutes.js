const express = require('express');
const {
    getTotalSalesOverTime,
    getSalesGrowthRate,
    getNewCustomersOverTime,
    getRepeatCustomers,
    getGeographicalDistribution,
    getCustomerLifetimeValueByCohorts
} = require('../controllers/analyticsController');

const router = express.Router();

router.get('/total-sales', getTotalSalesOverTime);
router.get('/sales-growth', getSalesGrowthRate);
router.get('/new-customers', getNewCustomersOverTime);
router.get('/repeat-customers', getRepeatCustomers);
router.get('/geographical-distribution', getGeographicalDistribution);
router.get('/customer-lifetime-value', getCustomerLifetimeValueByCohorts);

module.exports = router;
