const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    total_price_set: {
        shop_money: {
            amount: Number
        }
    },
    created_at: Date
});

module.exports = mongoose.model('Order', orderSchema);
