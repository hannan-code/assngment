const mongoose = require('mongoose');

const shopifyProductSchema = new mongoose.Schema({
    title: String,
    price: Number,
    created_at: Date,
});

const ShopifyProduct = mongoose.model('ShopifyProduct', shopifyProductSchema);

module.exports = ShopifyProduct;
