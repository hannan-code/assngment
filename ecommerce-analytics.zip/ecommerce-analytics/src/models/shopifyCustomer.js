const mongoose = require('mongoose');

const shopifyCustomerSchema = new mongoose.Schema({
    email: String,
    created_at: Date,
    orders_count: Number,
    total_spent: Number,
    default_address: {
        city: String,
    },
});

const ShopifyCustomer = mongoose.model('ShopifyCustomer', shopifyCustomerSchema);

module.exports = ShopifyCustomer;
