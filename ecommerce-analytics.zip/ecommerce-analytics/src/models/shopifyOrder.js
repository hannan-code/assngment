const mongoose = require('mongoose');

const shopifyOrderSchema = new mongoose.Schema({
    created_at: Date,
    total_price_set: {
        shop_money: {
            amount: Number,
        },
    },
    customer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ShopifyCustomer',
    },
});

const ShopifyOrder = mongoose.model('ShopifyOrder', shopifyOrderSchema);

module.exports = ShopifyOrder;
