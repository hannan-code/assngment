const ShopifyOrder = require('../models/shopifyOrder');
const ShopifyCustomer = require('../models/shopifyCustomer');

// 1. Total Sales Over Time
const getTotalSalesOverTime = async (req, res) => {
    try {
        const { interval } = req.query;

        const sales = await ShopifyOrder.aggregate([
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: interval === 'yearly' ? '%Y' :
                                    interval === 'quarterly' ? '%Y-%m' :
                                    interval === 'monthly' ? '%Y-%m' : '%Y-%m-%d',
                            date: '$created_at'
                        }
                    },
                    totalSales: { $sum: '$total_price_set.shop_money.amount' }
                }
            },
            { $sort: { _id: 1 } }
        ]).maxTimeMS(60000); // Set maxTimeMS to 60 seconds (60000 ms)

        res.json(sales);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// 2. Sales Growth Rate Over Time
const getSalesGrowthRate = async (req, res) => {
    try {
        const { interval } = req.query;

        const sales = await ShopifyOrder.aggregate([
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: interval === 'yearly' ? '%Y' :
                                    interval === 'quarterly' ? '%Y-%m' :
                                    interval === 'monthly' ? '%Y-%m' : '%Y-%m-%d',
                            date: '$created_at'
                        }
                    },
                    totalSales: { $sum: '$total_price_set.shop_money.amount' }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        const growthRate = sales.map((current, index, array) => {
            if (index === 0) return { ...current, growthRate: 0 };
            const previous = array[index - 1];
            const rate = ((current.totalSales - previous.totalSales) / previous.totalSales) * 100;
            return { ...current, growthRate: rate };
        });

        res.json(growthRate);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// 3. New Customers Added Over Time
const getNewCustomersOverTime = async (req, res) => {
    try {
        const { interval } = req.query;

        const newCustomers = await ShopifyCustomer.aggregate([
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: interval === 'yearly' ? '%Y' :
                                    interval === 'quarterly' ? '%Y-%m' :
                                    interval === 'monthly' ? '%Y-%m' : '%Y-%m-%d',
                            date: '$created_at'
                        }
                    },
                    newCustomers: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        res.json(newCustomers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// 4. Number of Repeat Customers
const getRepeatCustomers = async (req, res) => {
    try {
        const { interval } = req.query;

        const repeatCustomers = await ShopifyCustomer.aggregate([
            {
                $match: {
                    orders_count: { $gt: 1 }
                }
            },
            {
                $group: {
                    _id: {
                        $dateToString: {
                            format: interval === 'yearly' ? '%Y' :
                                    interval === 'quarterly' ? '%Y-%m' :
                                    interval === 'monthly' ? '%Y-%m' : '%Y-%m-%d',
                            date: '$created_at'
                        }
                    },
                    repeatCustomers: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);

        res.json(repeatCustomers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// 5. Geographical Distribution of Customers
const getGeographicalDistribution = async (req, res) => {
    try {
        const distribution = await ShopifyCustomer.aggregate([
            {
                $group: {
                    _id: '$default_address.city',
                    customerCount: { $sum: 1 }
                }
            },
            { $sort: { customerCount: -1 } }
        ]);

        res.json(distribution);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// 6. Customer Lifetime Value by Cohorts
const getCustomerLifetimeValueByCohorts = async (req, res) => {
    try {
        const lifetimeValue = await ShopifyCustomer.aggregate([
            {
                $group: {
                    _id: {
                        month: { $month: '$created_at' },
                        year: { $year: '$created_at' }
                    },
                    lifetimeValue: { $sum: '$total_spent' }
                }
            },
            { $sort: { '_id.year': 1, '_id.month': 1 } }
        ]);

        res.json(lifetimeValue);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getTotalSalesOverTime,
    getSalesGrowthRate,
    getNewCustomersOverTime,
    getRepeatCustomers,
    getGeographicalDistribution,
    getCustomerLifetimeValueByCohorts
};
