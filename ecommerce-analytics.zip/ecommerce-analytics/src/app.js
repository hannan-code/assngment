const express = require('express');
const app = express();
const connectDB = require('./db');
const Order = require('./models/Order');

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());

// Define the /api/orders route
app.get('/api/orders', async (req, res) => {
    try {
        const orders = await Order.find(); // Fetch all orders
        console.log('Fetched Orders:', orders); // Log fetched orders
        if (orders.length === 0) {
            return res.status(404).json({ message: 'No orders found' });
        }
        res.json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error.message); // Log error
        res.status(500).json({ message: error.message });
    }
});

// Additional routes can be defined here

module.exports = app;
